# Sara Letter + Private Admin Dashboard

النسخة دي مبنية على آخر صفحة رسالة ليك بدون تعديل نص الرسالة.

## بتعمل إيه؟
- صفحة الرسالة: `/` — نفس التصميم والخط.
- لوحة الأدمن: `/admin.html` — مفتاح خاص تدخل بيه، وتشوف إجمالي الفتحات وفتحات اليوم وآخر زيارة وآخر 12 فتحات ومنحنى الأيام.
- كل فتح للرسالة في تبويب متصفح يُسجل مرة واحدة تقريبًا.
- البيانات المخزنة: وقت الفتح فقط. لا يتم تخزين الاسم أو IP أو بصمة الجهاز أو نوع الجهاز.
- **مهم:** مستحيل تعرف مين الشخص من الإحصائيات دي. زيارة واحدة مش دليل إنها سارة، والزيارة مش دليل على قراءة الرسالة.
- أضفنا ملاحظة صغيرة في آخر الصفحة إن الزيارات بتتحسب بشكل مجهول الهوية.

## نشر المشروع على Netlify + GitHub (الطريقة المضمونة لدعم لوحة الأدمن)

### 1. ارفع المشروع على GitHub
1. فك ملف الـ ZIP.
2. أنشئ Repository جديد **Private** على https://github.com/new باسم sara-letter مثلا.
3. افتح PowerShell **داخل مجلد المشروع**، واكتب (بدّل USERNAME باسم حسابك):

```powershell
git init
git add .
git commit -m "Deploy private letter"
git branch -M main
git remote add origin https://github.com/USERNAME/sara-letter.git
git push -u origin main
```

إن طلب GitHub تسجيل دخول، كمل الدخول من المتصفح. ويمكنك أيضًا رفع الملفات من واجهة GitHub بشرط الحفاظ على هيكل مجلد `netlify/functions`.

### 2. Netlify
1. افتح https://app.netlify.com/.
2. Add new project → Import an existing project → GitHub.
3. اختار المستودع اللي أنشأته.
4. لو Netlify ماقرأش الإعدادات من `netlify.toml` تلقائيًا: Build command: `npm run build`, Publish directory: `.`, Functions directory: `netlify/functions`.
5. اضغط Deploy.

### 3. سر الأدمن (ضروري)
1. في إعدادات الموقع على Netlify، افتح **Environment variables**.
2. Add a variable:
   - Key: `ADMIN_KEY`
   - Value: اختر سر قوي عشوائي من 24 حرفًا على الأقل.
   - Scope: Functions (لو الخيار متاح)، وإلا All scopes.
3. Save ثم **Trigger deploy / Deploy site مرة تانية** علشان الدوال تقرأ القيمة الجديدة.
4. احتفظ بالسر لنفسك. **ممنوع** تحطه في `index.html` أو `admin.html` أو `netlify.toml` أو GitHub.

### 4. استخدام اللينكات
- رابط الرسالة: `https://YOUR-SITE.netlify.app/`
- رابط لوحة الأدمن: `https://YOUR-SITE.netlify.app/admin.html`
- استخدم مفتاح `ADMIN_KEY` للدخول للوحة.

### 5. التجربة
1. افتح رابط الرسالة من Incognito أو موبايل تاني.
2. افتح `/admin.html` واكتب السر واضغط عرض الإحصائيات.
3. لو فتحته مرتين في نفس التبويب، غالبًا هيتحسب مرة واحدة، ولو جلسة جديدة يتحسب فتح تاني.
4. ممكن يحصل تأخير بسيط لظهور أرقام Netlify Blobs؛ ولو الوظائف ما اشتغلتش، راجع Function logs في Netlify.

## معلومات مهمة
- Netlify Drop (رفع HTML مباشرة) **مش كفاية** لتشغيل Netlify Functions والتخزين. لازم نشر مجلد المشروع كاملًا باستخدام Git Integration أو Netlify CLI.
- هذا المشروع لا يقدر يتعرف على هوية الشخص أو يثبت إنه قرأ الرسالة، ولا يحاول يعمل ده.
- الزيارات تمثل فتحات مسجلة من المتصفح بعد تشغيل JavaScript، وليست إثباتًا للقراءة؛ ممكن متصفحات تمنع التتبع أو تحصل أخطاء اتصال.
- لو عايز تلغي التتبع، احذف سكريبت `/api/visit` من `index.html` ولا تظهر إحصائيات جديدة.
