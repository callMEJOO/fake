import { getStore } from '@netlify/blobs';
import { timingSafeEqual } from 'node:crypto';

function sameSecret(given, expected) {
  if (!given || !expected) return false;
  const a = Buffer.from(given, 'utf8');
  const b = Buffer.from(expected, 'utf8');
  return a.length === b.length && timingSafeEqual(a, b);
}

function cairoDate(value) {
  const parts = new Intl.DateTimeFormat('en-GB', {
    timeZone: 'Africa/Cairo', day: '2-digit', month: '2-digit', year: 'numeric'
  }).formatToParts(value);
  const fields = Object.fromEntries(parts.filter(x => x.type !== 'literal').map(x => [x.type, x.value]));
  return `${fields.year}-${fields.month}-${fields.day}`;
}

export default async function handler(request) {
  if (request.method !== 'GET') return new Response('Method not allowed', { status: 405, headers: { Allow: 'GET' } });

  // ADMIN_KEY must be configured in Netlify's environment variables UI.
  const expected = process.env.ADMIN_KEY;
  if (!expected || expected.length < 16) {
    return Response.json({ error: 'Admin is not configured. Set ADMIN_KEY (16+ chars) in Netlify environment variables.' }, {
      status: 503, headers: { 'Cache-Control': 'no-store' }
    });
  }
  if (!sameSecret(request.headers.get('x-admin-key'), expected)) {
    return Response.json({ error: 'Incorrect admin key' }, {
      status: 401, headers: { 'Cache-Control': 'no-store' }
    });
  }

  try {
    const store = getStore('anonymous-letter-visits');
    const timestamps = [];
    for await (const page of store.list({ paginate: true })) {
      for (const item of page.blobs) {
        // Data encodes only epoch milliseconds plus a random collision-avoidance ID.
        const epoch = Number(/^v_(\d{13})_/.exec(item.key)?.[1]);
        if (Number.isFinite(epoch) && epoch > 0) timestamps.push(epoch);
      }
    }
    timestamps.sort((a, b) => b - a);
    const today = cairoDate(new Date());
    const dates = {};
    for (const timestamp of timestamps) {
      const day = cairoDate(timestamp);
      dates[day] = (dates[day] || 0) + 1;
    }
    const series = Object.entries(dates).sort(([a], [b]) => a.localeCompare(b)).slice(-14);
    return Response.json({
      total: timestamps.length,
      today: dates[today] || 0,
      latest: timestamps[0] ? new Date(timestamps[0]).toISOString() : null,
      recent: timestamps.slice(0, 12).map(x => new Date(x).toISOString()),
      series: series.map(([date, count]) => ({ date, count })),
      timezone: 'Africa/Cairo',
      caveat: 'Anonymous page-open sessions only. This does not identify people or prove that anyone read the letter.'
    }, { headers: { 'Cache-Control': 'no-store', 'Pragma': 'no-cache' } });
  } catch (error) {
    console.error('Could not load anonymous stats', error);
    return Response.json({ error: 'Analytics temporarily unavailable' }, { status: 503, headers: { 'Cache-Control': 'no-store' } });
  }
}
