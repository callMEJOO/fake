import { getStore } from '@netlify/blobs';
import { randomUUID } from 'node:crypto';

// This endpoint records only an anonymous timestamp. No IP address, cookies,
// user-agent, referrer, or other identifying attributes are stored.
export default async function handler(request) {
  if (request.method !== 'POST') {
    return new Response('Method not allowed', { status: 405, headers: { Allow: 'POST' } });
  }

  // Ignore a cross-origin browser request. Native same-origin POSTs are allowed.
  const origin = request.headers.get('origin');
  if (origin && origin !== new URL(request.url).origin) {
    return new Response('Forbidden', { status: 403 });
  }

  try {
    const store = getStore('anonymous-letter-visits');
    const key = `v_${Date.now()}_${randomUUID()}`;
    await store.set(key, 'opened');
    return Response.json({ ok: true }, { headers: { 'Cache-Control': 'no-store' } });
  } catch (error) {
    console.error('Could not record an anonymous visit', error);
    return Response.json({ ok: false }, { status: 503 });
  }
}
